Installl
unpack Files in 

C:\Program Files (x86)\Roblox\Versions\version-9898fbc5d6bc4b1e

-------------------------------------------------------------------------------------------------------------
Info:

Install program coming in the future.