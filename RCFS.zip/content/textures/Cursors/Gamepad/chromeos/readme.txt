﻿=== ChromeOS Cursor Set ===

By: Anonymous

Download: http://www.rw-designer.com/cursor-set/chromeos

Author's description:

Chrome OS cursors. Nothin' special.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.